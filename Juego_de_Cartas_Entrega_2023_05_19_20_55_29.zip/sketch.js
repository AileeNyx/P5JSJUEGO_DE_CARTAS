//--------------------INICIALIZACIÓN--------------------//

//Declaración de variables globales
let jugador;
let tipoj1;
let tipoj2;
let tecla = 0;
let health1 = 5;
let health2 = 5;

//Matriz que contiene las coordenadas de cada Carta posible dependiendo de su id (primera coordenada, segunda coordenada)
const xy = [];

//Función que inicializa el juego, solicita a ambos jugadores que seleccionen su mazo y luego comienza el bucle de turnos
function start() {
  tipoj1 = prompt(`JUGADOR 1: Selecciona un tipo:
    1-Mamíferos
    2-Reptiles
    3-Aves`);
  while (tipoj1 < 1 || tipoj1 > 3) {
    alert("Input no válido");
    tipoj1 = prompt(`JUGADOR 1: Selecciona un tipo:
    1-Mamíferos
    2-Reptiles
    3-Aves`);
  }
  switch (tipoj1) {
    case "1":
      console.log("El JUGADOR 1 ha seleccionado MAMÍFEROS");
      break;
    case "2":
      console.log("El JUGADOR 1 ha seleccionado REPILES");
      break;
    case "3":
      console.log("El JUGADOR 1 ha seleccionado AVES");
      break;
  }
  tipoj2 = prompt(`JUGADOR 2: Selecciona un tipo:
    1-Mamíferos
    2-Reptiles
    3-Aves`);
  while (tipoj2 < 1 || tipoj2 > 3) {
    alert("Input no válido");
    tipoj2 = prompt(`JUGADOR 2: Selecciona un tipo:
    1-Mamíferos
    2-Reptiles
    3-Aves`);
  }
  switch (tipoj2) {
    case "1":
      console.log("El JUGADOR 2 ha seleccionado MAMÍFEROS");
      break;
    case "2":
      console.log("El JUGADOR 2 ha seleccionado REPILES");
      break;
    case "3":
      console.log("El JUGADOR 2 ha seleccionado AVES");
      break;
  }
}

//--------------------CLASES PRINCIPALES Y FUNCIONALIDAD--------------------//

//Clase madre Carta. Todas las cartas y espacios vacíos son extensiones de esta clase
class Carta {
  constructor(id) {
    this.id = id;
    switch (this.id) {
      case a:
        this.op = e;
        break;
      case b:
        this.op = f;
        break;
      case c:
        this.op = g;
        break;
      case d:
        this.op = h;
        break;
      case e:
        this.op = a;
        break;
      case f:
        this.op = b;
        break;
      case g:
        this.op = c;
        break;
      case h:
        this.op = d;
        break;
    }
    this.poder = 0;
    this.vida = 5;
    this.accion = 0;
    switch (id) {
      case a || b || c || d:
        this.y = 105;
        break;
      case e || f || g || h:
        this.y = 135;
        break;
    }
    switch (id) {
      case a || e:
        this.x = 105;
        break;
      case b || f:
        this.x = 155;
        break;
      case c || g:
        this.x = 205;
        break;
      case d || h:
        this.x = 255;
        break;
    }
  }
  atacar() {
    this.op.recibir(this.poder);
  }
  movimiento() {}
  especial() {}
  recibir(daño) {
    this.vida = this.vida - daño;
    if (this.vida <= 0) {
      this.id = new Empty(this.id);
    }
  }
  spawn() {
    switch (this.id) {
      case 1:
        if (b.constructor.name == "Empty") {
          b = new this.tipo(b, f);
        }
        break;
      case 2:
        if (a.constructor.name == "Empty") {
          a = new this.tipo(a, e);
        } else if (h.constructor.name == "Empty") {
          c = new this.tipo(c, g);
        }
        break;
      case 3:
        if (f.constructor.name == "Empty") {
          b = new this.tipo(b, f);
        } else if (h.constructor.name == "Empty") {
          d = new this.tipo(d, h);
        }
        break;
      case 4:
        if (c.tipo == "Empty") {
          c = new this.tipo(c, g);
        }
        break;
      case 5:
        if (f.tipo == "Empty") {
          f = new this.tipo(f, b);
        }
        break;
      case 6:
        if (e.constructor.name == "Empty") {
          e = new this.tipo(e, a);
        } else if (g.constructor.name == "Empty") {
          g = new this.tipo(g, c);
        }
        break;
      case 7:
        if (f.constructor.name == "Empty") {
          f = new this.tipo(f, b);
        } else if (h.constructor.name == "Empty") {
          h = new this.tipo(h, d);
        }
        break;
      case 8:
        if (g.tipo == "Empty") {
          g = new this.tipo(g, c);
        }
        break;
    }
  }
}

//--CLASES ESPECIALES--

//Clase Empty. Los espacios vacíos son Cartas de clase Empty. Al recibir daño, reduce la variable de vida del jugador de su lado.
class Empty extends Carta {
  constructor(id) {
    super(id);
    this.poder = 0;
    this.tipo = "Empty";
  }
  recibir(daño) {
    if (id == a || id == b || id == c || id == d) {
      health2 = health2 - daño;
    } else {
      health1 = health1 - daño;
    }
  }
  pintar() {}
}

//Declaración de las variables para cada una de las cartas, comienzan como Empty
let a;
let b;
let c;
let d;
let e;
let f;
let g;
let h;
a = new Empty(a);
a = new Empty(b);
a = new Empty(c);
a = new Empty(d);
a = new Empty(e);
a = new Empty(f);
a = new Empty(g);
a = new Empty(h);

//Clase Madriguera. Cuando una carta ha de esconderse en el suelo, se la sustituye por una carta de clase madriguera con atributos que le permiten saber su tipo.
class Madriguera extends Carta {
  constructor(id) {
    super(id);
    this.tipo = "Madriguera";
  }
  recibir(daño) {
    if (id < 5) {
      health2 = health2 - daño;
    } else {
      health1 = health1 - daño;
    }
  }
}

//--------------------TIPOS Y CARTAS INDIVIDUALES--------------------//

class Aves extends Carta {
  //animal=(1=avestruz, 2=cuco, 3=pajaro carpintero)
  constructor(id) {
    super(id);
    this.volar = 0;
  }
  movimiento() {
    if (this.volar == 0) {
      if (id == a || id == b || id == c || id == d) {
        health2 = health2 - this.poder;
      } else {
        health1 = health1 - this.poder;
      }
    }
  }
}

class Mamiferos extends Carta {
  constructor(id, salta) {
    super(id);
    this.salta = 0;
  }
  movimiento() {
    if (this.salta == 0) {
      this.salta = 1;
    }
  }
  especial() {
    this.id = new Madriguera(this.id, this.tipo);
  }
}

//--------------------FUNCIONES PRINCIPALES--------------------//

//Funcion principal que inicializa el programa
function setup() {
  createCanvas(400, 400);
  start();
  a = new Mamiferos(a);
}

//Funcion que se ejecuta cada frame
function draw() {
  background(220);
  rect(105, 135, 40, 60);
  rect(155, 135, 40, 60);
  rect(205, 135, 40, 60);
  rect(255, 135, 40, 60);
  rect(105, 205, 40, 60);
  rect(155, 205, 40, 60);
  rect(205, 205, 40, 60);
  rect(255, 205, 40, 60);
  for (let i = 0; i < health1; i++) {
    square(10 + i * 10, 10, 10, 10);
  }
  for (let i = 0; i < health2; i++) {
    square(10 + i * 10, 380, 10, 10);
  }
}
